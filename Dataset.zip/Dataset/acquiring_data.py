#!/usr/bin/env python
# coding: utf-8

import xml.etree.ElementTree as ET
import os
import requests
import urllib.request

"""API key provided by cyclomedia - https://www.cyclomedia.com/nl"""


#Tried to get access of url directly using api key

"""
url = 'https://atlas.cyclomedia.com/panoramarendering/ListByaddress/NL/Westerstraat,%20Amsterdam%201015/?apiKey=mentionapikeyhere'
r = requests.get(url)
print(r)
root = ET.fromstring(r.content) 
print(r)
tree = ET.parse(response)
"""
#the above code might raise issue of authorization 401 error
#solution by userid from cyclomedia
"""Other way is to download as xml directly from cyclomedia portal,
and parse through the xml.
"""
#Geting the xml from OS directory 
tree = ET.parse('C:/Users/BarathidhasanShanmat/OneDrive - Kadaster/Documenten/Object detection/xml_files/amsteram_egelantiersgracht.xml')

#finding the root of the xml
root = tree.getroot()
print(root)
print(root.tag)

"""Parsing through the XML
Removing recording date and viewing direction as they are not required
Collecting onli recording ID as they are unique values 
"""
rec_id = []
for x in root:
    x.attrib.pop("recording-date") #removes the attribute date
    x.attrib.pop("viewing-direction") #removes the viewing direction
    print(x.attrib)#gives only recording id of each image
    y = x.attrib['recording-id']
    print(y)
    rec_id.append(y)
    #rec_id = x.findall("recording ID")
    #for rid in x.attrib:
     #   id_rec = rid.text
      #  recordingid.append(id_rec)
    
print(rec_id)

"""general rendering API:-
https://atlas.cyclomedia.com/PanoramaRendering/Render/rec_id/?width=1024&height=786&srsName=epsg:28992&yaw=0&pitch=0&hfov=90&filename=ABC&apiKey=mentionapikeyhere
"""


"""The folllowing parameters are given specific values to correct the perspective of the cycloroma images, 
yaw: Horizontal direction in degrees in the centre of the generated image.
pitc: Vertical direction in degrees in the centre of the generated image.
hfov: Horizontal field of view in degrees.
"""
#geting the url of all data from ID
def getPushshiftData():
    img_data = list() #creating a list of url
    for ID in rec_id:
        img_url = f'https://atlas.cyclomedia.com/PanoramaRendering/Render/{ID}/?width=1024&height=1024&srsName=epsg:28992&yaw=-20&pitch=5&hfov=70&filename=ABC&apiKey=mentionapikeyhere'
        #req = requests.get(img_url)
        #print(img_url)
        img_data.append(img_url)
    return img_data

url_list = getPushshiftData()

print(len(url_list)) #number of image urls
#automatic download wasn't acheived because of the API issue, thus downloaded mannualy using the above printed urls

#Below is the trial code for downloading as jpg automatically
"""Parsing over the list of URLs and downloading as .jpg format (image)
"""
filename = 1

for url in url_list:
    try:
        urllib.request.urlretrieve(url, f'{filename}.jpg')
        filename += 1
    except Exception as exc:
        print(f"Exception occued while downloading image from url {url} {str(exc)}")
        
#comment: 401 error , authorization issue might occur


